import io
from PIL import Image
from pathlib import Path
import torch
from torchvision import transforms
from model import SiameseNetwork

class DocumentImageProcessor:
    def __init__(self, model_path='cnn/model.pth'):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = SiameseNetwork().to(self.device)
        self.model.load_state_dict(torch.load(model_path))
        self.model.eval()
        
        self.transform = transforms.Compose([
            transforms.Resize((64, 64)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    
    def process_image_data(self, image_data):
        """Convert raw image data to tensor."""
        try:
            # Convert bytes to PIL Image
            image = Image.open(io.BytesIO(image_data)).convert('RGB')
            # Transform and add batch dimension
            return self.transform(image).unsqueeze(0).to(self.device)
        except Exception as e:
            print(f"Error processing image: {e}")
            return None
    
    def compare_document_images(self, images1, images2, threshold=1.0):
        """Compare two sets of document images."""
        matches = []
        
        for idx1, img1_data in enumerate(images1):
            img1_tensor = self.process_image_data(img1_data)
            if img1_tensor is None:
                continue
            
            for idx2, img2_data in enumerate(images2):
                img2_tensor = self.process_image_data(img2_data)
                if img2_tensor is None:
                    continue
                
                with torch.no_grad():
                    output1, output2 = self.model(img1_tensor, img2_tensor)
                    distance = torch.pairwise_distance(output1, output2).item()
                    
                    if distance < threshold:
                        matches.append({
                            'index1': idx1,
                            'index2': idx2,
                            'similarity': 1.0 - (distance / threshold)
                        })
        
        return matches