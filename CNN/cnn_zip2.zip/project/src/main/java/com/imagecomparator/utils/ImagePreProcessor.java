package com.imagecomparator.utils;

import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ImagePreProcessor {
    private static final int HEIGHT = 64;
    private static final int WIDTH = 64;
    private static final int CHANNELS = 3;

    public INDArray processImage(String imagePath) throws IOException {
        BufferedImage img = ImageIO.read(new File(imagePath));
        BufferedImage resized = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        
        // Use better quality scaling
        Graphics2D g2d = resized.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.drawImage(img, 0, 0, WIDTH, HEIGHT, null);
        g2d.dispose();

        float[][][] imageArray = new float[CHANNELS][HEIGHT][WIDTH];
        
        // Improved normalization
        for (int y = 0; y < HEIGHT; y++) {
            for (int x = 0; x < WIDTH; x++) {
                int rgb = resized.getRGB(x, y);
                // Normalize to [-1, 1] range instead of [0, 1]
                imageArray[0][y][x] = (((rgb >> 16) & 0xFF) / 127.5f) - 1.0f;
                imageArray[1][y][x] = (((rgb >> 8) & 0xFF) / 127.5f) - 1.0f;
                imageArray[2][y][x] = ((rgb & 0xFF) / 127.5f) - 1.0f;
            }
        }

        return Nd4j.create(imageArray).reshape(1, CHANNELS, HEIGHT, WIDTH);
    }
}