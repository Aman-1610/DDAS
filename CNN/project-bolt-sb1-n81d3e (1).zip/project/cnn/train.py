import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from model import SiameseNetwork, ContrastiveLoss
from dataset import ImagePairDataset
import os

def train_model(train_dir, num_epochs=10, batch_size=32, learning_rate=0.001):
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}')
    
    # Create dataset and dataloader
    dataset = ImagePairDataset(train_dir)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    
    # Initialize model and move to device
    model = SiameseNetwork().to(device)
    criterion = ContrastiveLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    
    # Training loop
    print('Starting training...')
    for epoch in range(num_epochs):
        running_loss = 0.0
        for i, (img1, img2, label) in enumerate(dataloader):
            # Move data to device
            img1, img2, label = img1.to(device), img2.to(device), label.to(device)
            
            # Zero gradients
            optimizer.zero_grad()
            
            # Forward pass
            output1, output2 = model(img1, img2)
            
            # Calculate loss
            loss = criterion(output1, output2, label)
            
            # Backward pass and optimize
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item()
            
            if i % 10 == 9:
                print(f'[{epoch + 1}, {i + 1}] loss: {running_loss / 10:.3f}')
                running_loss = 0.0
    
    print('Finished Training')
    
    # Save the model
    model_path = 'cnn/model.pth'
    torch.save(model.state_dict(), model_path)
    print(f'Model saved to {model_path}')

if __name__ == '__main__':
    train_dir = 'training_data'
    if not os.path.exists(train_dir):
        os.makedirs(train_dir)
        print(f'Created training directory: {train_dir}')
        print('Please add your training images to this directory before running training.')
        print('Organize images in subdirectories by class/category.')
        exit(1)
    
    train_model(train_dir)