package com.imagecomparator.training;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DatasetLoader {
    public List<ImagePair> loadTrainingData(String baseDir) {
        List<ImagePair> pairs = new ArrayList<>();
        File root = new File(baseDir);
        File[] categories = root.listFiles(File::isDirectory);
        
        if (categories == null) {
            throw new RuntimeException("No categories found in " + baseDir);
        }

        // Generate similar pairs (same category)
        for (File category : categories) {
            File[] images = category.listFiles(file -> 
                file.getName().toLowerCase().matches(".*\\.(jpg|jpeg|png)$"));
            
            if (images == null) continue;

            for (int i = 0; i < images.length; i++) {
                for (int j = i + 1; j < images.length; j++) {
                    pairs.add(new ImagePair(
                        images[i].getPath(),
                        images[j].getPath(),
                        true
                    ));
                }
            }
        }

        // Generate different pairs (different categories)
        for (int i = 0; i < categories.length; i++) {
            for (int j = i + 1; j < categories.length; j++) {
                File[] images1 = categories[i].listFiles(file -> 
                    file.getName().toLowerCase().matches(".*\\.(jpg|jpeg|png)$"));
                File[] images2 = categories[j].listFiles(file -> 
                    file.getName().toLowerCase().matches(".*\\.(jpg|jpeg|png)$"));
                
                if (images1 == null || images2 == null) continue;

                for (int k = 0; k < Math.min(images1.length, 5); k++) {
                    for (int l = 0; l < Math.min(images2.length, 5); l++) {
                        pairs.add(new ImagePair(
                            images1[k].getPath(),
                            images2[l].getPath(),
                            false
                        ));
                    }
                }
            }
        }

        return pairs;
    }
}