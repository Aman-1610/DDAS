import os
import sys
from duplicate_detector import DuplicateDetector

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 main.py <folder1> <folder2>")
        sys.exit(1)
    
    folder1 = sys.argv[1]
    folder2 = sys.argv[2]
    
    detector = DuplicateDetector()
    duplicates = detector.find_duplicates(folder1, folder2)
    detector.generate_report(duplicates)

if __name__ == "__main__":
    main()