import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';
import { DuplicateDetector } from './duplicateDetector.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function main() {
    const args = process.argv.slice(2);
    
    if (args.length !== 2) {
        console.log('Usage: node index.js <folder1> <folder2>');
        console.log('\nSupported file types:');
        console.log('- Images: .png, .jpg, .jpeg, .gif, .bmp');
        console.log('- Documents: .docx, .pptx, .pdf');
        process.exit(1);
    }
    
    const folder1 = resolve(__dirname, args[0]);
    const folder2 = resolve(__dirname, args[1]);
    
    console.log('\nScanning directories:');
    console.log(`Directory 1: ${folder1}`);
    console.log(`Directory 2: ${folder2}`);
    
    const detector = new DuplicateDetector();
    const duplicates = await detector.findDuplicates(folder1, folder2);
    detector.generateReport(duplicates);
}

main().catch(error => {
    console.error('Error:', error.message);
    process.exit(1);
});