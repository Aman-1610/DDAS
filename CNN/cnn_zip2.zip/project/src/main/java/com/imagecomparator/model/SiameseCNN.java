package com.imagecomparator.model;

import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.*;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.learning.config.Adam;

public class SiameseCNN {
    private MultiLayerNetwork network;
    private static final int HEIGHT = 64;
    private static final int WIDTH = 64;
    private static final int CHANNELS = 3;
    private static final int EMBEDDING_SIZE = 128;

    public SiameseCNN() {
        this.network = createNetwork();
    }

    private MultiLayerNetwork createNetwork() {
        MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
            .seed(123)
            .weightInit(WeightInit.XAVIER)
            .updater(new Adam(0.001))
            .list()
            .layer(0, new ConvolutionLayer.Builder()
                .kernelSize(3,3)
                .stride(1,1)
                .padding(1,1)
                .nIn(CHANNELS)
                .nOut(64)
                .activation(Activation.RELU)
                .build())
            .layer(1, new SubsamplingLayer.Builder()
                .kernelSize(2,2)
                .stride(2,2)
                .poolingType(SubsamplingLayer.PoolingType.MAX)
                .build())
            .layer(2, new ConvolutionLayer.Builder()
                .kernelSize(3,3)
                .stride(1,1)
                .padding(1,1)
                .nOut(128)
                .activation(Activation.RELU)
                .build())
            .layer(3, new SubsamplingLayer.Builder()
                .kernelSize(2,2)
                .stride(2,2)
                .poolingType(SubsamplingLayer.PoolingType.MAX)
                .build())
            .layer(4, new DenseLayer.Builder()
                .nOut(EMBEDDING_SIZE)
                .activation(Activation.RELU)
                .build())
            .setInputType(InputType.convolutional(HEIGHT, WIDTH, CHANNELS))
            .build();

        MultiLayerNetwork net = new MultiLayerNetwork(conf);
        net.init();
        return net;
    }

    public MultiLayerNetwork getNetwork() {
        return network;
    }
}