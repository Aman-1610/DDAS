Add your training images here in the following structure:

training_data/
  ├── class1/
  │   ├── image1.jpg
  │   ├── image2.jpg
  │   └── ...
  ├── class2/
  │   ├── image1.jpg
  │   ├── image2.jpg
  │   └── ...
  └── ...

Each subdirectory represents a class/category of images.
Images in the same directory are considered similar/duplicates.