package com.imagecomparator;

public class TrainingLauncher {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java -cp target/cnn-image-comparator-1.0-SNAPSHOT.jar " +
                             "com.imagecomparator.TrainingLauncher <training_data_dir>");
            System.exit(1);
        }

        String trainingDataDir = args[0];
        System.out.println("Starting model training with data from: " + trainingDataDir);

        try {
            ModelTrainer trainer = new ModelTrainer();
            trainer.train(trainingDataDir);
        } catch (Exception e) {
            System.err.println("Error during training: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}