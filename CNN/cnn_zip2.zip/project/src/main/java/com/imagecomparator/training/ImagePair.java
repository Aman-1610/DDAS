package com.imagecomparator.training;

public class ImagePair {
    private final String image1Path;
    private final String image2Path;
    private final boolean isSimilar;

    public ImagePair(String image1Path, String image2Path, boolean isSimilar) {
        this.image1Path = image1Path;
        this.image2Path = image2Path;
        this.isSimilar = isSimilar;
    }

    public String getImage1Path() { return image1Path; }
    public String getImage2Path() { return image2Path; }
    public boolean isSimilar() { return isSimilar; }
}