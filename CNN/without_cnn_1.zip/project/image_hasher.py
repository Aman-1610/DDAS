import os
import hashlib
from typing import Dict, List, Tuple

class ImageHasher:
    def __init__(self):
        self.supported_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp'}

    def is_image_file(self, filename: str) -> bool:
        return any(filename.lower().endswith(ext) for ext in self.supported_extensions)

    def get_file_hash(self, filepath: str) -> str:
        """Calculate SHA-256 hash of a file"""
        with open(filepath, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()

    def get_image_files(self, directory: str) -> List[str]:
        """Get all image files in a directory"""
        image_files = []
        try:
            for filename in os.listdir(directory):
                if self.is_image_file(filename):
                    full_path = os.path.join(directory, filename)
                    if os.path.isfile(full_path):
                        image_files.append(full_path)
        except Exception as e:
            print(f"Error accessing directory {directory}: {e}")
        return image_files

    def find_duplicates(self, dir1: str, dir2: str) -> List[Tuple[str, str]]:
        """Find duplicate images between two directories"""
        duplicates = []
        
        # Get all image files from both directories
        files1 = self.get_image_files(dir1)
        files2 = self.get_image_files(dir2)
        
        # Calculate hashes for first directory
        hashes1 = {f: self.get_file_hash(f) for f in files1}
        
        # Compare with second directory
        for file2 in files2:
            hash2 = self.get_file_hash(file2)
            for file1, hash1 in hashes1.items():
                if hash2 == hash1:
                    duplicates.append((file1, file2))
        
        return duplicates