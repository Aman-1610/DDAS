import { readFile, readdir } from 'fs/promises';
import { extname, join } from 'path';
import { createHash } from 'crypto';
import { DocumentImageExtractor } from './documentExtractor.js';

export class DuplicateDetector {
    constructor() {
        this.imageExtensions = new Set(['.png', '.jpg', '.jpeg', '.gif', '.bmp']);
        this.documentExtensions = new Set(['.docx', '.pptx', '.pdf']);
        this.docExtractor = new DocumentImageExtractor();
    }

    calculateHash(data) {
        return createHash('sha256').update(data).digest('hex');
    }

    async getFileContent(filePath) {
        const content = { images: [], source: filePath };
        const ext = extname(filePath).toLowerCase();

        try {
            if (this.imageExtensions.has(ext)) {
                const data = await readFile(filePath);
                content.images.push({
                    data,
                    hash: this.calculateHash(data),
                    source: filePath
                });
            } else if (this.documentExtensions.has(ext)) {
                const images = await this.docExtractor.extractImages(filePath);
                images.forEach((data, idx) => {
                    content.images.push({
                        data,
                        hash: this.calculateHash(data),
                        source: `${filePath}#image${idx}`
                    });
                });
            }
        } catch (error) {
            console.error(`Error processing file ${filePath}:`, error.message);
        }

        return content;
    }

    async findDuplicates(folder1, folder2) {
        console.log('Starting document and image comparison...');
        const duplicates = [];

        try {
            const files1 = await readdir(folder1);
            const files2 = await readdir(folder2);

            for (const file1 of files1) {
                const path1 = join(folder1, file1);
                const content1 = await this.getFileContent(path1);

                for (const file2 of files2) {
                    const path2 = join(folder2, file2);
                    const content2 = await this.getFileContent(path2);

                    content1.images.forEach(img1 => {
                        content2.images.forEach(img2 => {
                            if (img1.hash === img2.hash && img1.source !== img2.source) {
                                duplicates.push([img1.source, img2.source]);
                            }
                        });
                    });
                }
            }
        } catch (error) {
            console.error('Error scanning directories:', error.message);
        }

        return duplicates;
    }

    generateReport(duplicates) {
        if (duplicates.length === 0) {
            console.log('No duplicate images found.');
            return;
        }

        console.log(`\nFound ${duplicates.length} duplicate pairs:`);
        duplicates.forEach(([source1, source2]) => {
            console.log('\nDuplicate detected:');
            
            const formatSource = (source) => {
                if (source.includes('#image')) {
                    const [docPath, imgNum] = source.split('#');
                    return `Embedded image (${imgNum}) in document: ${docPath}`;
                }
                return `Image file: ${source}`;
            };
            
            console.log(formatSource(source1));
            console.log(formatSource(source2));
            console.log('-'.repeat(50));
        });
    }
}