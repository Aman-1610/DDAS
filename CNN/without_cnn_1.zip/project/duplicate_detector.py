import os
import hashlib
import logging

class DuplicateDetector:
    def __init__(self, chunk_size=8192):
        self.chunk_size = chunk_size
        self.logger = self._setup_logger()

    def _setup_logger(self):
        logger = logging.getLogger('DuplicateDetector')
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

    def calculate_hash(self, file_path):
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(self.chunk_size), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except Exception as e:
            self.logger.error(f"Error processing {file_path}: {str(e)}")
            return None

    def get_file_hashes(self, folder_path):
        file_hashes = {}
        
        if not os.path.exists(folder_path):
            self.logger.error(f"Folder {folder_path} does not exist")
            return file_hashes

        image_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.bmp'}
        
        for root, _, files in os.walk(folder_path):
            for filename in files:
                if any(filename.lower().endswith(ext) for ext in image_extensions):
                    file_path = os.path.join(root, filename)
                    file_hash = self.calculate_hash(file_path)
                    if file_hash:
                        file_hashes[file_path] = file_hash
        
        return file_hashes

    def find_duplicates(self, folder1, folder2):
        self.logger.info("Starting duplicate detection...")
        
        hashes1 = self.get_file_hashes(folder1)
        hashes2 = self.get_file_hashes(folder2)
        
        duplicates = []
        
        for path1, hash1 in hashes1.items():
            for path2, hash2 in hashes2.items():
                if hash1 == hash2:
                    duplicates.append((path1, path2))
        
        return duplicates

    def generate_report(self, duplicates):
        if not duplicates:
            self.logger.info("No duplicate files found.")
            return

        self.logger.info(f"Found {len(duplicates)} duplicate pairs:")
        for path1, path2 in duplicates:
            self.logger.info(f"\nDuplicate files:")
            self.logger.info(f"File 1: {path1}")
            self.logger.info(f"File 2: {path2}")
            self.logger.info("-" * 50)