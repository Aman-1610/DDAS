package com.imagecomparator;

public class Main {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java -jar image-comparator.jar <image1_path> <image2_path>");
            System.exit(1);
        }

        String image1Path = args[0];
        String image2Path = args[1];

        try {
            ImageComparator comparator = new ImageComparator();
            boolean areSimilar = comparator.areSimilar(image1Path, image2Path);
            double similarity = comparator.compareImages(image1Path, image2Path);

            System.out.println("\nImage Comparison Results:");
            System.out.println("-------------------------");
            System.out.println("Similarity score: " + String.format("%.2f", similarity));
            System.out.println("Images are " + (areSimilar ? "similar" : "different"));
            
        } catch (Exception e) {
            System.err.println("Error comparing images: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}