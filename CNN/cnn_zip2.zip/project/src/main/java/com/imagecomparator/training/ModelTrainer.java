package com.imagecomparator.training;

import com.imagecomparator.model.SiameseCNN;
import com.imagecomparator.utils.ImagePreProcessor;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;

import java.io.File;
import java.util.List;

public class ModelTrainer {
    private final SiameseCNN model;
    private final ImagePreProcessor preProcessor;
    private static final int BATCH_SIZE = 32;
    private static final int NUM_EPOCHS = 100;
    private static final double LEARNING_RATE = 0.0001;

    public ModelTrainer() {
        this.model = new SiameseCNN();
        this.preProcessor = new ImagePreProcessor();
    }

    public void train(String trainingDataDir) throws Exception {
        System.out.println("Loading training data...");
        DatasetLoader loader = new DatasetLoader();
        List<ImagePair> pairs = loader.loadTrainingData(trainingDataDir);
        
        System.out.println("Starting training with " + pairs.size() + " image pairs");
        MultiLayerNetwork network = model.getNetwork();
        
        for (int epoch = 0; epoch < NUM_EPOCHS; epoch++) {
            double epochLoss = 0;
            int numBatches = 0;
            
            for (int i = 0; i < pairs.size(); i += BATCH_SIZE) {
                int batchSize = Math.min(BATCH_SIZE, pairs.size() - i);
                DataSet batch = createBatch(pairs.subList(i, i + batchSize));
                
                network.fit(batch);
                epochLoss += network.score();
                numBatches++;
            }
            
            double avgLoss = epochLoss / numBatches;
            System.out.printf("Epoch %d/%d - Loss: %.4f%n", 
                            epoch + 1, NUM_EPOCHS, avgLoss);
            
            // Save checkpoint every 10 epochs
            if ((epoch + 1) % 10 == 0) {
                String modelPath = String.format("models/siamese_cnn_epoch_%d.zip", epoch + 1);
                new File("models").mkdirs();
                network.save(new File(modelPath));
                System.out.println("Saved model checkpoint: " + modelPath);
            }
        }
        
        // Save final model
        new File("models").mkdirs();
        network.save(new File("models/siamese_cnn_final.zip"));
        System.out.println("Training completed. Final model saved.");
    }

    private DataSet createBatch(List<ImagePair> pairs) throws Exception {
        int batchSize = pairs.size();
        INDArray input1 = Nd4j.create(batchSize, 3, 64, 64);
        INDArray input2 = Nd4j.create(batchSize, 3, 64, 64);
        INDArray labels = Nd4j.create(batchSize, 1);

        for (int i = 0; i < batchSize; i++) {
            ImagePair pair = pairs.get(i);
            input1.putRow(i, preProcessor.processImage(pair.getImage1Path()));
            input2.putRow(i, preProcessor.processImage(pair.getImage2Path()));
            labels.putScalar(i, pair.isSimilar() ? 1.0 : 0.0);
        }

        return new DataSet(input1, labels);
    }
}