import torch
from model import SiameseNetwork
from torchvision import transforms
from PIL import Image
import torch.nn.functional as F

class ImageComparator:
    def __init__(self, model_path='cnn/model.pth'):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = SiameseNetwork().to(self.device)
        self.model.load_state_dict(torch.load(model_path))
        self.model.eval()
        
        self.transform = transforms.Compose([
            transforms.Resize((64, 64)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
    
    def compare_images(self, img1_path, img2_path, threshold=1.0):
        # Load and transform images
        img1 = Image.open(img1_path).convert('RGB')
        img2 = Image.open(img2_path).convert('RGB')
        
        img1 = self.transform(img1).unsqueeze(0).to(self.device)
        img2 = self.transform(img2).unsqueeze(0).to(self.device)
        
        # Get embeddings
        with torch.no_grad():
            output1, output2 = self.model(img1, img2)
        
        # Calculate distance
        distance = F.pairwise_distance(output1, output2).item()
        
        # Return True if images are similar (distance below threshold)
        return distance < threshold, distance