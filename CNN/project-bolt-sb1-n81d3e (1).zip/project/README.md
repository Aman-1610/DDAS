## Document and Image Duplicate Detector

A Node.js application that detects duplicate images across directories, including images embedded in documents (DOCX, PPTX, PDF).

### Features

- Supports multiple image formats (PNG, JPG, JPEG, GIF, BMP)
- Extracts and compares images from documents (DOCX, PPTX, PDF)
- Generates detailed reports of duplicate images
- Handles embedded images in documents

### Usage

```bash
node index.js <folder1> <folder2>
```

### Supported File Types

- Images: PNG, JPG, JPEG, GIF, BMP
- Documents: DOCX, PPTX, PDF