package com.imagecomparator;

import com.imagecomparator.model.SiameseCNN;
import com.imagecomparator.utils.ImagePreProcessor;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.ops.transforms.Transforms;

import java.io.IOException;

public class ImageComparator {
    private final SiameseCNN model;
    private final ImagePreProcessor preProcessor;
    private static final double SIMILARITY_THRESHOLD = 0.95; // Increased threshold
    private static final double DISTANCE_WEIGHT = 0.7;
    private static final double FEATURE_WEIGHT = 0.3;

    public ImageComparator() {
        this.model = new SiameseCNN();
        this.preProcessor = new ImagePreProcessor();
    }

    public double compareImages(String image1Path, String image2Path) throws IOException {
        INDArray img1 = preProcessor.processImage(image1Path);
        INDArray img2 = preProcessor.processImage(image2Path);

        // Get CNN embeddings
        INDArray embedding1 = model.getNetwork().output(img1);
        INDArray embedding2 = model.getNetwork().output(img2);

        // Calculate cosine similarity
        double cosineSim = Transforms.cosineSim(embedding1, embedding2).getDouble(0);
        
        // Calculate Euclidean distance (normalized)
        double euclideanDist = Transforms.euclideanDistance(embedding1, embedding2).getDouble(0);
        double normalizedDist = 1.0 / (1.0 + euclideanDist); // Convert distance to similarity score
        
        // Weighted combination of similarity measures
        double combinedSimilarity = (DISTANCE_WEIGHT * normalizedDist + 
                                   FEATURE_WEIGHT * cosineSim);
        
        return Math.max(0.0, Math.min(1.0, combinedSimilarity)); // Ensure result is between 0 and 1
    }

    public boolean areSimilar(String image1Path, String image2Path) throws IOException {
        double similarity = compareImages(image1Path, image2Path);
        return similarity > SIMILARITY_THRESHOLD;
    }
}