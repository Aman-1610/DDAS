import torch
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image
import os

class ImagePairDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform or transforms.Compose([
            transforms.Resize((64, 64)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225])
        ])
        
        self.image_pairs = []
        self.labels = []
        
        # Generate pairs from the dataset
        self._generate_pairs()
    
    def _generate_pairs(self):
        folders = [f for f in os.listdir(self.root_dir) 
                  if os.path.isdir(os.path.join(self.root_dir, f))]
        
        for folder in folders:
            folder_path = os.path.join(self.root_dir, folder)
            images = [f for f in os.listdir(folder_path) 
                     if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            
            # Generate positive pairs (same class)
            for i in range(len(images)):
                for j in range(i + 1, len(images)):
                    self.image_pairs.append((
                        os.path.join(folder_path, images[i]),
                        os.path.join(folder_path, images[j])
                    ))
                    self.labels.append(0)  # 0 for same class
            
            # Generate negative pairs (different classes)
            for other_folder in folders:
                if other_folder != folder:
                    other_path = os.path.join(self.root_dir, other_folder)
                    other_images = [f for f in os.listdir(other_path)
                                  if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
                    
                    for img1 in images[:len(other_images)]:
                        for img2 in other_images:
                            self.image_pairs.append((
                                os.path.join(folder_path, img1),
                                os.path.join(other_path, img2)
                            ))
                            self.labels.append(1)  # 1 for different class
    
    def __len__(self):
        return len(self.image_pairs)
    
    def __getitem__(self, idx):
        img1_path, img2_path = self.image_pairs[idx]
        
        img1 = Image.open(img1_path).convert('RGB')
        img2 = Image.open(img2_path).convert('RGB')
        
        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)
        
        return img1, img2, torch.FloatTensor([self.labels[idx]])