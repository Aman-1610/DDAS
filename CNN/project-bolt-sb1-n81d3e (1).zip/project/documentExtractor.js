import fs from 'fs/promises';
import path from 'path';
import mammoth from 'mammoth';
import JSZip from 'jszip';
import { PDFExtract } from 'pdf.js-extract';

export class DocumentImageExtractor {
    constructor() {
        this.supportedExtensions = {
            '.docx': this._extractFromDocx.bind(this),
            '.pptx': this._extractFromPptx.bind(this),
            '.pdf': this._extractFromPdf.bind(this)
        };
        this.pdfExtractor = new PDFExtract();
    }

    async _extractFromDocx(filePath) {
        try {
            const buffer = await fs.readFile(filePath);
            const zip = new JSZip();
            const content = await zip.loadAsync(buffer);
            const images = [];
            
            for (const [filename, file] of Object.entries(content.files)) {
                if (filename.startsWith('word/media/') && !file.dir) {
                    const imageData = await file.async('nodebuffer');
                    images.push(imageData);
                }
            }
            
            return images;
        } catch (error) {
            console.error(`Error extracting images from DOCX: ${error.message}`);
            return [];
        }
    }

    async _extractFromPptx(filePath) {
        try {
            const buffer = await fs.readFile(filePath);
            const zip = new JSZip();
            const content = await zip.loadAsync(buffer);
            const images = [];
            
            for (const [filename, file] of Object.entries(content.files)) {
                if (filename.startsWith('ppt/media/') && !file.dir) {
                    const imageData = await file.async('nodebuffer');
                    images.push(imageData);
                }
            }
            
            return images;
        } catch (error) {
            console.error(`Error extracting images from PPTX: ${error.message}`);
            return [];
        }
    }

    async _extractFromPdf(filePath) {
        try {
            const options = {};
            const data = await this.pdfExtractor.extract(filePath, options);
            const images = [];
            
            if (data.pages) {
                for (const page of data.pages) {
                    if (page.content) {
                        const imageContent = page.content.filter(item => item.type === 'image');
                        for (const image of imageContent) {
                            if (image.data) {
                                images.push(Buffer.from(image.data));
                            }
                        }
                    }
                }
            }
            
            return images;
        } catch (error) {
            console.error(`Error extracting images from PDF: ${error.message}`);
            return [];
        }
    }

    async extractImages(filePath) {
        const ext = path.extname(filePath).toLowerCase();
        
        if (!this.supportedExtensions[ext]) {
            console.warn(`Unsupported file type: ${ext}`);
            return [];
        }
        
        try {
            if (!(await this._fileExists(filePath))) {
                console.warn(`File does not exist: ${filePath}`);
                return [];
            }

            console.log(`Extracting images from: ${filePath}`);
            const images = await this.supportedExtensions[ext](filePath);
            console.log(`Found ${images.length} images in ${filePath}`);
            return images;
        } catch (error) {
            console.error(`Error extracting images from ${filePath}: ${error.message}`);
            return [];
        }
    }

    async _fileExists(filePath) {
        try {
            await fs.access(filePath);
            return true;
        } catch {
            return false;
        }
    }
}